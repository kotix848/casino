import './scss/main.scss'
import {useEffect, useState} from "react";
import bells from './assets/bells.png'
import treeSeven from './assets/777.png'
import lemon from './assets/lemon.png'
import grape from './assets/grape.png'

function App() {
    const [slotItems] = useState([
        [grape, treeSeven, lemon],
        [bells, grape, lemon],
        [bells, treeSeven, grape]
    ]);
    const [slotResults, setSlotResults] = useState([
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ]);

    const [score, setScore] = useState(parseInt(localStorage.getItem('score') || 1000000));
    const [isAutoSpinning, setIsAutoSpinning] = useState(false);
    const [bet, setBet] = useState(4000);
    const [star, setStar] = useState(parseInt(localStorage.getItem('star') || 500));
    const [result, setResult] = useState('');
    const storedScore = localStorage.getItem('score');
    const storedStar = localStorage.getItem('star');
    const storedBet = localStorage.getItem('bet');

    useEffect(() => {
        if (!storedStar) {
            localStorage.setItem('star', star.toString());
        }
        if (!storedScore) {
            localStorage.setItem('score', score.toString());
        }
        if (!storedBet) {
            localStorage.setItem('bet', bet.toString());
        }
    }, [storedStar, storedScore, storedBet, star, score, bet]);

    const handleBetPlus = () => {
        setBet(bet + 1000);
        if (bet >= score) {
            setBet(bet);
            localStorage.setItem('bet', bet.toString());
        }
    };

    const handleBetMinus = () => {
        setBet(bet - 1000);
        if (bet <= 1000) {
            setBet(bet);
            localStorage.setItem('bet', bet.toString());
        }
    };

    const getRandomItem = (array) => {
        return array[Math.floor(Math.random() * array.length)];
    };

    const checkResult = (results) => {
        const column2 = results[1];

        if (
            column2[0] === column2[1] &&
            column2[1] === column2[2]
        ) {
            const winAmount = bet * 5;
            setScore(score + winAmount);
            localStorage.setItem('score', score + winAmount);
            setResult(winAmount);
            setTimeout(() => {
                setResult(" ");
            }, 4000);
        }
    }

    const handleSpin = () => {
        if (!isAutoSpinning && score < bet) {
            alert('Недостаточно средств!');
            return;
        }

        setStar(prevStar => prevStar + 500);
        const newSlotResults = slotItems.map(column =>
            column.map(() => getRandomItem(column))
        );
        setSlotResults(newSlotResults);
        setScore(prevScore => {
            const updatedScore = prevScore - bet;
            localStorage.setItem('score', updatedScore.toString());
            return updatedScore;
        });
        setTimeout(() => {
            checkResult(newSlotResults);
        });
    };

    const autoSpin = () => {
        setIsAutoSpinning(true);

        const interval = setInterval(() => {
            setScore(prevScore => {
                if (prevScore >= bet) {
                    const updatedScore = prevScore - bet;
                    localStorage.setItem('score', updatedScore.toString());
                    return updatedScore;
                } else {
                    clearInterval(interval);
                    setIsAutoSpinning(false);
                    alert('Недостаточно средств!');
                    return prevScore;
                }
            });

            handleSpin();
        }, 1000);
    };

    return (
        <>
            <div className="line top">
                <div className="container">
                    <div className="content">
                        <div className="left btn">
                            <svg width="11" height="19" viewBox="0 0 11 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g filter="url(#filter0_di_13_132)">
                                    <path
                                        d="M7.83749 14.0013C7.68809 14.0018 7.54048 13.9688 7.4055 13.9048C7.27052 13.8407 7.15161 13.7473 7.05749 13.6313L2.22749 7.63125C2.08041 7.45232 2 7.22788 2 6.99625C2 6.76463 2.08041 6.54018 2.22749 6.36125L7.22749 0.361252C7.39723 0.157036 7.64114 0.0286112 7.90556 0.0042315C8.16999 -0.0201482 8.43327 0.0615137 8.63749 0.231252C8.8417 0.400991 8.97013 0.644902 8.99451 0.909329C9.01889 1.17375 8.93723 1.43704 8.76749 1.64125L4.29749 7.00125L8.61749 12.3613C8.73977 12.508 8.81745 12.6868 8.84133 12.8763C8.86521 13.0659 8.83429 13.2583 8.75223 13.4308C8.67018 13.6034 8.54042 13.7488 8.37831 13.8499C8.2162 13.9509 8.02852 14.0035 7.83749 14.0013Z"
                                        fill="white"></path>
                                </g>
                                <defs>
                                    <filter id="filter0_di_13_132" x="0" y="-1" width="10.9987" height="19.0013"
                                            filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
                                        <feFlood floodOpacity="0" result="BackgroundImageFix"></feFlood>
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                                       values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                                                       result="hardAlpha"></feColorMatrix>
                                        <feOffset dy="2"></feOffset>
                                        <feGaussianBlur stdDeviation="1"></feGaussianBlur>
                                        <feComposite in2="hardAlpha" operator="out"></feComposite>
                                        <feColorMatrix type="matrix"
                                                       values="0 0 0 0 0.200128 0 0 0 0 0.055243 0 0 0 0 0.308333 0 0 0 1 0"></feColorMatrix>
                                        <feBlend mode="normal" in2="BackgroundImageFix"
                                                 result="effect1_dropShadow_13_132"></feBlend>
                                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_13_132"
                                                 result="shape"></feBlend>
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                                       values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                                                       result="hardAlpha"></feColorMatrix>
                                        <feOffset dy="-1"></feOffset>
                                        <feGaussianBlur stdDeviation="1"></feGaussianBlur>
                                        <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"></feComposite>
                                        <feColorMatrix type="matrix"
                                                       values="0 0 0 0 0.7955 0 0 0 0 0 0 0 0 0 0.925 0 0 0 0.58 0"></feColorMatrix>
                                        <feBlend mode="normal" in2="shape"
                                                 result="effect2_innerShadow_13_132"></feBlend>
                                    </filter>
                                </defs>
                            </svg>
                        </div>
                        <div className="star input">
                            <p className="text">
                                {star}/9000
                            </p>
                        </div>
                        <div className="cash input">
                            <p className="text">
                                {score}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="slot-content">
                <div className="container">
                    <div className="slot-machine">
                        {slotResults.map((column, columnIndex) => (
                            <div key={columnIndex} className="slot-column">
                                {column.map((item, itemIndex) => (
                                    <div key={itemIndex} className="slot"><img src={item} alt=""/></div>
                                ))}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="line bottom">
                <div className="container">
                    <div className="content">
                        <div className="minus btn" onClick={() => handleBetMinus()}>
                            <svg width="11" height="6" viewBox="0 0 11 6" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g filter="url(#filter0_di_14_232)">
                                    <path d="M8.08789 0.158203V2.88281H2.90234V0.158203H8.08789Z" fill="white"/>
                                </g>
                                <defs>
                                    <filter id="filter0_di_14_232" x="0.902344" y="-0.841797" width="9.18555"
                                            height="7.72461" filterUnits="userSpaceOnUse"
                                            colorInterpolationFilters="sRGB">
                                        <feFlood floodOpacity="0" result="BackgroundImageFix"/>
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                                       values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                                                       result="hardAlpha"/>
                                        <feOffset dy="2"/>
                                        <feGaussianBlur stdDeviation="1"/>
                                        <feComposite in2="hardAlpha" operator="out"/>
                                        <feColorMatrix type="matrix"
                                                       values="0 0 0 0 0.200128 0 0 0 0 0.055243 0 0 0 0 0.308333 0 0 0 1 0"/>
                                        <feBlend mode="normal" in2="BackgroundImageFix"
                                                 result="effect1_dropShadow_14_232"/>
                                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_14_232"
                                                 result="shape"/>
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                                       values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                                                       result="hardAlpha"/>
                                        <feOffset dy="-1"/>
                                        <feGaussianBlur stdDeviation="1"/>
                                        <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
                                        <feColorMatrix type="matrix"
                                                       values="0 0 0 0 0.7955 0 0 0 0 0 0 0 0 0 0.925 0 0 0 0.58 0"/>
                                        <feBlend mode="normal" in2="shape" result="effect2_innerShadow_14_232"/>
                                    </filter>
                                </defs>
                            </svg>
                        </div>
                        <div className="bet input"><p className="text">{bet}</p></div>
                        <div className="plus btn" onClick={() => handleBetPlus()}>
                            <svg width="15" height="13" viewBox="0 0 15 13" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g filter="url(#filter0_di_14_226)">
                                    <path
                                        d="M2.79297 3.91797H6.29883V0.402344H8.68164V3.91797H12.207V6.30078H8.68164V9.79688H6.29883V6.30078H2.79297V3.91797Z"
                                        fill="white"/>
                                </g>
                                <defs>
                                    <filter id="filter0_di_14_226" x="0.792969" y="-0.597656" width="13.4141"
                                            height="14.3945" filterUnits="userSpaceOnUse"
                                            colorInterpolationFilters="sRGB">
                                        <feFlood floodOpacity="0" result="BackgroundImageFix"/>
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                                       values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                                                       result="hardAlpha"/>
                                        <feOffset dy="2"/>
                                        <feGaussianBlur stdDeviation="1"/>
                                        <feComposite in2="hardAlpha" operator="out"/>
                                        <feColorMatrix type="matrix"
                                                       values="0 0 0 0 0.200128 0 0 0 0 0.055243 0 0 0 0 0.308333 0 0 0 1 0"/>
                                        <feBlend mode="normal" in2="BackgroundImageFix"
                                                 result="effect1_dropShadow_14_226"/>
                                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_14_226"
                                                 result="shape"/>
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                                       values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                                                       result="hardAlpha"/>
                                        <feOffset dy="-1"/>
                                        <feGaussianBlur stdDeviation="1"/>
                                        <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
                                        <feColorMatrix type="matrix"
                                                       values="0 0 0 0 0.7955 0 0 0 0 0 0 0 0 0 0.925 0 0 0 0.58 0"/>
                                        <feBlend mode="normal" in2="shape" result="effect2_innerShadow_14_226"/>
                                    </filter>
                                </defs>
                            </svg>
                        </div>
                        <div className="win input">
                            <p className="win-txt">
                                WIN
                            </p>
                            <p className="win-cash">
                                {result}
                            </p>
                        </div>
                        <div className="auto-btn" onClick={() => autoSpin()}>
                            <p className="txt">AUTO</p>
                        </div>
                        <div className="spin-btn" onClick={() => handleSpin()}>
                            <p className="txt">SPIN</p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default App
